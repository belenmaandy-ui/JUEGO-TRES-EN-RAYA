# Tic-Tac-Toe (Ta-Te-Ti) en Python

Este es un sencillo juego de **Tic-Tac-Toe (Ta-Te-Ti)** para consola, escrito en Python.

## Cómo ejecutar

```bash
python tictactoe.py
```

## Requisitos

- Python 3.7 o superior

## Licencia

MIT License.

def print_board(tablero):
    for fila in tablero:
        print(" | ".join(fila))
        print("-" * 9)

def check_winner(tablero, jugador):
    # Revisar filas
    for fila in tablero:
        if all(s == jugador for s in fila):
            return True

    # Revisar columnas
    for columna in range(3):
        if all(tablero[fila][columna] == jugador for fila in range(3)):
            return True

    # Revisar diagonales
    if all(tablero[i][i] == jugador for i in range(3)) or \
       all(tablero[i][2 - i] == jugador for i in range(3)):
        return True

    return False


def main():
    tablero = [[" " for _ in range(3)] for _ in range(3)]
    jugador = "X"

    for _ in range(9):
        print_board(tablero)
        try:
            fila, col = map(int, input(f"Jugador {jugador}, ingrese fila y columna (0-2): ").split())
        except ValueError:
            print("Entrada inválida. Debe ingresar dos números separados por espacio.")
            continue

        if fila not in range(3) or col not in range(3):
            print("Coordenadas fuera del rango. Use valores entre 0 y 2.")
            continue

        if tablero[fila][col] == " ":
            tablero[fila][col] = jugador

            if check_winner(tablero, jugador):
                print_board(tablero)
                print(f"¡El jugador {jugador} gana!")
                break

            jugador = "O" if jugador == "X" else "X"
        else:
            print("¡Movimiento inválido! La casilla ya está ocupada.")

    else:
        print("¡Es un empate!")


if __name__ == "__main__":
    main()
